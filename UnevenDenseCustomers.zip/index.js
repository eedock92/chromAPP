const title = document.getElementById("title");
title.innerHTML = "Hi! From JS";






const byungSooInfo = {
  name : "ByungSoo Kim",
  age : 29,
  gender: "Male",
  isHansome: true,
  favMovies: ["Along the gods", "LOTR", "Oldboy"],
  favFood: [
    {
       name : "Kimchi",
       fatty : false     
    },
    {name : "Cheese burger",
       fatty: true
    }
       
  ]
}



